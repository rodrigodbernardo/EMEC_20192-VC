import cv2
import numpy as np
from PIL import Image
import sys

def translation(img_in):
    lin, col = img_in.shape[:2]

    tMatrix = np.float32([[1,0,70],[0,1,110]])

    return cv2.warpAffine(img_in,tMatrix,(col,lin))

def rotation(img_in, angle):
  
    (h, w) = img_in.shape[:2]
    (cX, cY) = (w // 2, h // 2)
 

    M = cv2.getRotationMatrix2D((cX, cY), angle, 1.0)
    cos = np.abs(M[0, 0])
    sin = np.abs(M[0, 1])
 
    nW = int((h * sin) + (w * cos))
    nH = int((h * cos) + (w * sin))
 
    M[0, 2] += (nW / 2) - cX
    M[1, 2] += (nH / 2) - cY
 
    return cv2.warpAffine(img_in, M, (nW, nH))

def scale(img_in,scale):

    width = int(img_in.shape[1] * scale / 100)
    height = int(img_in.shape[0] * scale / 100)
    dim = (width, height)
        
    return cv2.resize(img_in, dim, interpolation = cv2.INTER_AREA)

def erosion(img_in,kType):
    if kType == '1':
        kernel = np.ones((3,3),np.uint8)
    elif kType == '2':
        kernel = np.ones((5,5),np.uint8)
    elif kType == '3':
        kernel = np.array([[0, 1, 0],[1, 1, 1],[0, 1, 0]], dtype = np.uint8)
    return cv2.erode(img_in,kernel,iterations = 5)

def dilation(img_in,kType):
    if kType == '1':
        kernel = np.ones((3,3),np.uint8)
    elif kType == '2':
        kernel = np.ones((5,5),np.uint8)
    elif kType == '3':
        kernel = np.array([[0, 1, 0],[1, 1, 1],[0, 1, 0]], dtype = np.uint8)
    return cv2.dilate(img_in,kernel,iterations = 5)

def regionGrowingBinary(img_in):
    lin,col = img_in.shape

  #  for x in range(0,lin):
       # for y in ra
m = .imread
m = plt.imshow

erose